-- MariaDB dump 10.19  Distrib 10.11.9-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.9-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` int(11) NOT NULL,
  `primaryOwnerId` int(11) DEFAULT NULL,
  `fieldId` int(11) DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_bveiqgziidrtabvsqbtchunpojlwynhclagd` (`primaryOwnerId`),
  CONSTRAINT `fk_bveiqgziidrtabvsqbtchunpojlwynhclagd` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ltdqmfbbfsobokiqsbegyzapthcbvgymfduv` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `pluginId` int(11) DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT 1,
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_emnrdehcyrzvmjianxwrmymsobvpuaedqyuq` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_jkynwiyjqtsaqexayloaezghqebdpgyxkczm` (`dateRead`),
  KEY `fk_bryhusvdhwohsyerurgelyvypmoettmbtkmb` (`pluginId`),
  CONSTRAINT `fk_bryhusvdhwohsyerurgelyvypmoettmbtkmb` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jdedyllspceuzaxrlbzpcyjckxzsquqlnshk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` int(11) NOT NULL,
  `volumeId` int(11) NOT NULL,
  `uri` text DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT 0,
  `recordId` int(11) DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT 0,
  `inProgress` tinyint(1) DEFAULT 0,
  `completed` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gjaajuczwavhcxhpsxnlamthtuukakxmvgfz` (`sessionId`,`volumeId`),
  KEY `idx_mrdbocnijiqqalreficoxxatumthtlapokfh` (`volumeId`),
  CONSTRAINT `fk_atkgsvnynuxzxnkmjatlqjcrhbsnexgldlnp` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_djmoywgkubvfmedtpwbnupmzxairwijdzsvi` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexingsessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text DEFAULT NULL,
  `totalEntries` int(11) DEFAULT NULL,
  `processedEntries` int(11) NOT NULL DEFAULT 0,
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT 0,
  `isCli` tinyint(1) DEFAULT 0,
  `actionRequired` tinyint(1) DEFAULT 0,
  `processIfRootEmpty` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `uploaderId` int(11) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fqkkrefqpdwbjrvjhoqsysbngsufqtbltsse` (`filename`,`folderId`),
  KEY `idx_tlhyxrhseqzpeiwsdokpqqanfzouudzbvyyb` (`folderId`),
  KEY `idx_qikpzoonyuwbfrthffrbyajaqjcqgxrfmjjr` (`volumeId`),
  KEY `fk_iqrxcizccjnctzlanfwvymsxzhsitwkvdkwq` (`uploaderId`),
  CONSTRAINT `fk_hoihwojymjxkzyqbexqzodiguszweyjxrxxz` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hucyolsebclcdybynltbkqhxirnibfoubovm` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iqrxcizccjnctzlanfwvymsxzhsitwkvdkwq` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ltinfbxwepikkxwqupdglffyetvhhpprvotg` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets_sites` (
  `assetId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `alt` text DEFAULT NULL,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_gapdevlgapasqtmfmiznyikuxgdtttegonmh` (`siteId`),
  CONSTRAINT `fk_gapdevlgapasqtmfmiznyikuxgdtttegonmh` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_nfaydfglmvjqyxjpsoffjquobbaweglvbxtf` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authenticator` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `oldTimestamp` int(11) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cbycsnbxchvkdnuxzesthroosjiixwnjmlxt` (`userId`),
  CONSTRAINT `fk_cbycsnbxchvkdnuxzesthroosjiixwnjmlxt` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ukkdinwcvvihhcwdxoieltbhcyuwyqycwilb` (`groupId`),
  KEY `fk_dwcqwqnemrtasjsdlsuigfwbgsdklpmbdbzo` (`parentId`),
  CONSTRAINT `fk_bhuuzwmaqkyfpmmntgrwgvajpvphgcjjsarc` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dwcqwqnemrtasjsdlsuigfwbgsdklpmbdbzo` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_dzkuedypgwwagfwwstrbdroqnamejljtnkvk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zhkxowznsbechhypulhcmztecqbuujqnnjne` (`name`),
  KEY `idx_ghhyrwuihsrrlsmelbfwwsthtvdnkqvtaqgb` (`handle`),
  KEY `idx_vofdnohrgiayglpcyrmvwpmvblrognvyycpa` (`structureId`),
  KEY `idx_cupsqswsfenlgulvmixrvrlemwkitiaubebx` (`fieldLayoutId`),
  KEY `idx_nwlhvakqtwjnkrpufqrrywmgvpawpogmpdkt` (`dateDeleted`),
  CONSTRAINT `fk_bvxmqsaftsrixibtabqyhyajajedrweubwvh` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xjikpfipmwsyztzpezvpyryiwtdthiauhmju` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ozlbrfndvdbiiqfuijjndamrdshatxwvwnvr` (`groupId`,`siteId`),
  KEY `idx_lqdlwqzoojbncqghetwiuquvqtrnnzpnkznf` (`siteId`),
  CONSTRAINT `fk_umkegysyakhiierarnclzobytiazzxzjlgow` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xyklectjwnoztcdwlrjhiyjijosnfdrhench` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedattributes` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_fhhsbtvlmluqjjzdofleknheulybbkqfopbi` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_zjvyuzqqbwfxyqepzpovsdmhticmkaxdmqpw` (`siteId`),
  KEY `fk_xgnhixvfafrdjfditoidkjwskqfhfucsjvos` (`userId`),
  CONSTRAINT `fk_tdyhlegtzdcfsdlpbkqukguuolhnotnhquys` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xgnhixvfafrdjfditoidkjwskqfhfucsjvos` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_zjvyuzqqbwfxyqepzpovsdmhticmkaxdmqpw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES
(1,1,'lastPasswordChangeDate','2024-10-31 17:51:41',0,1),
(1,1,'password','2024-10-31 17:51:41',0,1),
(2,1,'postDate','2024-10-31 17:35:26',0,1),
(2,1,'slug','2024-10-31 17:33:36',0,1),
(2,1,'title','2024-10-31 17:33:36',0,1),
(2,1,'uri','2024-10-31 17:33:36',0,1),
(7,1,'postDate','2024-10-31 17:39:39',0,1),
(7,1,'slug','2024-10-31 17:39:17',0,1),
(7,1,'title','2024-10-31 17:39:17',0,1),
(7,1,'uri','2024-10-31 17:39:17',0,1),
(9,1,'slug','2024-10-31 17:38:14',0,1),
(9,1,'title','2024-10-31 17:38:14',0,1),
(12,1,'postDate','2024-10-31 17:39:32',0,1),
(12,1,'slug','2024-10-31 17:39:32',0,1),
(12,1,'title','2024-10-31 17:39:32',0,1),
(19,1,'slug','2024-10-31 17:43:25',0,1),
(19,1,'uri','2024-10-31 17:43:25',0,1),
(20,1,'postDate','2024-10-31 17:43:17',0,1),
(20,1,'title','2024-10-31 17:43:25',0,1),
(21,1,'postDate','2024-10-31 17:43:55',0,1),
(21,1,'slug','2024-10-31 17:43:32',0,1),
(21,1,'title','2024-10-31 17:43:32',0,1),
(21,1,'uri','2024-10-31 17:43:32',0,1),
(22,1,'postDate','2024-10-31 17:43:33',0,1),
(22,1,'slug','2024-10-31 17:43:37',0,1),
(22,1,'title','2024-10-31 17:43:37',0,1),
(23,1,'postDate','2024-10-31 17:43:43',0,1),
(23,1,'title','2024-10-31 17:43:43',0,1),
(57,1,'title','2024-10-31 17:47:29',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedfields` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_lxiwxbakljtglrgnovlsosoqemivarjgubda` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_ayawwhzkjmtprdexvrywnbtrlqcqaeekzlzx` (`siteId`),
  KEY `fk_zmizwnwbynoymftrazjhwrwqanwmdjoixdtt` (`fieldId`),
  KEY `fk_xgwdjekhxvntbjwrsxmleqjvbjqhpiveczff` (`userId`),
  CONSTRAINT `fk_ayawwhzkjmtprdexvrywnbtrlqcqaeekzlzx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_hqdkmythuthxqajydizfrpmtxgjsggeepaxt` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xgwdjekhxvntbjwrsxmleqjvbjqhpiveczff` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_zmizwnwbynoymftrazjhwrwqanwmdjoixdtt` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES
(2,1,1,'74ee7590-9942-4110-9769-7c053c72d749','2024-10-31 17:33:40',0,1),
(2,1,2,'8e609db9-7fd0-4064-8e8a-a200a7bcc0d0','2024-10-31 17:35:26',0,1),
(2,1,3,'1b7c094c-995b-47e7-be8b-1f55903c2355','2024-10-31 17:33:38',0,1),
(5,1,1,'74ee7590-9942-4110-9769-7c053c72d749','2024-10-31 17:36:08',0,1),
(5,1,2,'8e609db9-7fd0-4064-8e8a-a200a7bcc0d0','2024-10-31 17:36:08',0,1),
(7,1,4,'1e8b1505-ded4-4d74-a21f-79ebb195b524','2024-10-31 17:39:17',0,1),
(9,1,4,'1e8b1505-ded4-4d74-a21f-79ebb195b524','2024-10-31 17:38:14',0,1),
(12,1,1,'2c11b749-28b5-4aec-bb90-85031716810f','2024-10-31 17:39:32',0,1),
(12,1,3,'ec2e6634-a421-41f8-a7ec-82dec4cb7f13','2024-10-31 17:39:32',0,1),
(19,1,4,'1e8b1505-ded4-4d74-a21f-79ebb195b524','2024-10-31 17:43:25',0,1),
(20,1,1,'2c11b749-28b5-4aec-bb90-85031716810f','2024-10-31 17:43:25',0,1),
(20,1,2,'e571706a-c7ac-4419-b935-b7148454c8f1','2024-10-31 17:43:25',0,1),
(20,1,3,'ec2e6634-a421-41f8-a7ec-82dec4cb7f13','2024-10-31 17:43:25',0,1),
(21,1,4,'1e8b1505-ded4-4d74-a21f-79ebb195b524','2024-10-31 17:47:29',0,1),
(22,1,1,'2c11b749-28b5-4aec-bb90-85031716810f','2024-10-31 17:43:55',0,1),
(22,1,2,'e571706a-c7ac-4419-b935-b7148454c8f1','2024-10-31 17:43:55',0,1),
(22,1,3,'ec2e6634-a421-41f8-a7ec-82dec4cb7f13','2024-10-31 17:43:40',0,1),
(23,1,3,'3ebf00a1-282f-4396-94c8-ee67edeb306d','2024-10-31 17:43:43',0,1),
(27,1,1,'2c11b749-28b5-4aec-bb90-85031716810f','2024-10-31 17:44:20',0,1),
(27,1,3,'ec2e6634-a421-41f8-a7ec-82dec4cb7f13','2024-10-31 17:44:20',0,1),
(45,1,1,'2c11b749-28b5-4aec-bb90-85031716810f','2024-10-31 17:46:47',0,1),
(45,1,2,'e571706a-c7ac-4419-b935-b7148454c8f1','2024-10-31 17:46:47',0,1),
(49,1,1,'2c11b749-28b5-4aec-bb90-85031716810f','2024-10-31 17:47:11',0,1),
(49,1,2,'e571706a-c7ac-4419-b935-b7148454c8f1','2024-10-31 17:47:11',0,1),
(49,1,3,'ec2e6634-a421-41f8-a7ec-82dec4cb7f13','2024-10-31 17:47:11',0,1),
(56,1,1,'2c11b749-28b5-4aec-bb90-85031716810f','2024-10-31 17:47:29',0,1),
(56,1,2,'e571706a-c7ac-4419-b935-b7148454c8f1','2024-10-31 17:47:29',0,1),
(56,1,3,'ec2e6634-a421-41f8-a7ec-82dec4cb7f13','2024-10-31 17:47:29',0,1),
(57,1,3,'3ebf00a1-282f-4396-94c8-ee67edeb306d','2024-10-31 17:47:29',0,1),
(61,1,4,'1e8b1505-ded4-4d74-a21f-79ebb195b524','2024-10-31 17:47:40',0,1),
(62,1,1,'2c11b749-28b5-4aec-bb90-85031716810f','2024-10-31 17:47:40',0,1),
(62,1,2,'e571706a-c7ac-4419-b935-b7148454c8f1','2024-10-31 17:47:40',0,1),
(62,1,3,'ec2e6634-a421-41f8-a7ec-82dec4cb7f13','2024-10-31 17:47:40',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_meflyzfevejzdackjflnrumxgoanffrdbimz` (`userId`),
  CONSTRAINT `fk_meflyzfevejzdackjflnrumxgoanffrdbimz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` text DEFAULT NULL,
  `traces` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`traces`)),
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nfghabyklcbgieawdhuipqnaegddojoggmmk` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `trackChanges` tinyint(1) NOT NULL DEFAULT 0,
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_wapszuzehkznyjbqjtywzppwkqahwxevzahf` (`creatorId`,`provisional`),
  KEY `idx_sdbfetnaxohjvsbcahfncqukmejxnrjdgndx` (`saved`),
  KEY `fk_pnwwtfhevzsxmkhsjbgpebyfqzfufuyjwqpq` (`canonicalId`),
  CONSTRAINT `fk_pnwwtfhevzsxmkhsjbgpebyfqzfufuyjwqpq` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pyqvbafbfliklpaooxascjlbakeebfhwjerv` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
INSERT INTO `drafts` VALUES
(2,NULL,1,0,'First draft',NULL,0,NULL,0),
(3,2,1,0,'Draft 1','',1,NULL,1),
(4,NULL,1,0,'First draft',NULL,0,NULL,0),
(7,NULL,1,0,'First draft',NULL,0,NULL,1),
(8,NULL,1,0,'First draft',NULL,0,NULL,0),
(9,NULL,1,0,'First draft',NULL,0,NULL,0),
(13,NULL,1,0,'First draft',NULL,0,NULL,0),
(15,NULL,1,0,'First draft','',0,NULL,1),
(40,21,1,1,'Draft 1','',1,NULL,1);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elementactivity` (
  `elementId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `draftId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_lnbfxoudmkzsdnkidsarilrvdxodmckszanr` (`elementId`,`timestamp`,`userId`),
  KEY `fk_smzsrklhxvyfsdjabjfdupvyswvsfeuhazlf` (`userId`),
  KEY `fk_qvynynpotbaqriccojgjnvqqibfyjagiyuua` (`siteId`),
  KEY `fk_bhvrzvsayvmyhemgbubzfrardgobzjmkyifq` (`draftId`),
  CONSTRAINT `fk_bhvrzvsayvmyhemgbubzfrardgobzjmkyifq` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nxrnqypyanwabgqmaydifcuidwveymwfubdt` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qvynynpotbaqriccojgjnvqqibfyjagiyuua` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_smzsrklhxvyfsdjabjfdupvyswvsfeuhazlf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES
(2,1,1,3,'save','2024-10-31 17:36:08'),
(7,1,1,NULL,'edit','2024-10-31 17:39:45'),
(7,1,1,NULL,'save','2024-10-31 17:39:39'),
(9,1,1,NULL,'save','2024-10-31 17:38:14'),
(12,1,1,NULL,'save','2024-10-31 17:39:32'),
(19,1,1,NULL,'save','2024-10-31 17:43:25'),
(21,1,1,NULL,'edit','2024-10-31 17:47:40'),
(21,1,1,NULL,'save','2024-10-31 17:47:29');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `archived` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zhjjmivwcfolnneqllohmucfswbiklmtxmyj` (`dateDeleted`),
  KEY `idx_hunuxsvdmeqcpjmtpagjgebjmslgwrhxlqrb` (`fieldLayoutId`),
  KEY `idx_ncnduqxvuxzbzzjcjqjjyalkbybjhclmxaqv` (`type`),
  KEY `idx_cwmzvmgrimshwatxnrjgulydntrqjfzvnbaa` (`enabled`),
  KEY `idx_czgvsuckeudrgteekvdbviqplcppudhzvhjt` (`canonicalId`),
  KEY `idx_umtyzdrdibnjeunydclmskxunuuhaycrcujf` (`archived`,`dateCreated`),
  KEY `idx_lrqqkxzdducqrduklfszilkhggzbhhapxosu` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_cdpekwtsrbfncksxfrpdtbgplvvagyrwflib` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_xieuzqwpstnygbacsbhvbrmhjvxduyfqylzg` (`draftId`),
  KEY `fk_xjcjeouojinejgbktriztuqmwzvevezpjcxo` (`revisionId`),
  CONSTRAINT `fk_aouqrzrkrmlrzzywhcnddmejgomamgrkvwvx` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ejtpsdvcksslypptdvldzrfurauecmmktnnx` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xieuzqwpstnygbacsbhvbrmhjvxduyfqylzg` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xjcjeouojinejgbktriztuqmwzvevezpjcxo` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES
(1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-10-31 17:29:17','2024-10-31 17:51:41',NULL,NULL,NULL,'35c0f03c-2940-4680-b4ee-b3e5a2501754'),
(2,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:33:30','2024-10-31 17:35:26',NULL,NULL,NULL,'53096ea6-c12b-4934-9899-2f8345e31f8c'),
(3,NULL,2,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:33:30','2024-10-31 17:33:30',NULL,NULL,NULL,'f74359f9-2bea-4188-a238-b2b55ecc8aa5'),
(4,2,NULL,1,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:35:26','2024-10-31 17:35:26',NULL,NULL,NULL,'5cb6c72a-dc86-4c2b-aa57-2ba3d096959c'),
(5,2,3,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:36:08','2024-10-31 17:36:08',NULL,NULL,NULL,'c0bf6d29-e91f-4d5d-9b5d-a5861cbf16fd'),
(6,NULL,4,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:36:13','2024-10-31 17:36:13',NULL,NULL,NULL,'c771fc7d-c9fd-4f56-8f86-df05c9f8356a'),
(7,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:37:47','2024-10-31 17:39:39',NULL,NULL,NULL,'0805ce01-e095-4668-bfdc-2160acd87cf1'),
(9,NULL,7,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:38:10','2024-10-31 17:39:12',NULL,'2024-10-31 17:39:12',NULL,'7a4f6a66-af77-4b46-abe6-64686e604dae'),
(10,NULL,8,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:38:14','2024-10-31 17:38:14',NULL,NULL,NULL,'0304ce28-0b0f-4570-abe5-b246f3f0bb4b'),
(11,NULL,9,NULL,2,'craft\\elements\\Entry',1,0,'2024-10-31 17:39:17','2024-10-31 17:39:17',NULL,NULL,NULL,'c7f47a9f-8d80-48c7-8384-a2a3ecbba74f'),
(12,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-10-31 17:39:23','2024-10-31 17:39:45',NULL,NULL,NULL,'31fabe18-baa2-4820-ab4e-c0bf87fedf40'),
(13,7,NULL,2,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:39:39','2024-10-31 17:39:39',NULL,NULL,NULL,'faad66c5-f78b-45dd-b215-7baa2e3a5c2d'),
(14,12,NULL,3,3,'craft\\elements\\Entry',1,0,'2024-10-31 17:39:32','2024-10-31 17:39:39',NULL,NULL,NULL,'9726a96f-9862-46b1-a265-4565f74de322'),
(17,NULL,13,NULL,2,'craft\\elements\\Entry',1,0,'2024-10-31 17:39:59','2024-10-31 17:39:59',NULL,NULL,NULL,'53a143d5-8d8f-4cc7-a338-1d0ee55ad44f'),
(19,NULL,15,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:42:23','2024-10-31 17:43:25',NULL,NULL,NULL,'b63de41f-e856-49e5-b893-0eccaf93d041'),
(20,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-10-31 17:42:26','2024-10-31 17:43:25',NULL,NULL,NULL,'c148bfe3-c7eb-4c87-945a-371e67eced15'),
(21,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:43:28','2024-10-31 17:47:29',NULL,NULL,NULL,'bf2519b4-f94f-4092-acb4-dea8e7c1dab4'),
(22,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-10-31 17:43:32','2024-10-31 17:44:20',NULL,'2024-10-31 17:44:20',NULL,'046b8283-2a90-430e-9200-b1701d1bb9aa'),
(23,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-10-31 17:43:43','2024-10-31 17:43:48',NULL,'2024-10-31 17:43:48',NULL,'792fd977-d938-4705-b546-2eed8d70fa27'),
(24,21,NULL,4,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:43:55','2024-10-31 17:43:55',NULL,NULL,NULL,'5c0b5182-a8c0-428e-8888-1bc0fcb55be8'),
(25,22,NULL,5,3,'craft\\elements\\Entry',1,0,'2024-10-31 17:43:55','2024-10-31 17:43:55',NULL,'2024-10-31 17:44:20',NULL,'618608da-d734-4509-9632-c24fd23dc888'),
(27,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-10-31 17:44:00','2024-10-31 17:46:47',NULL,'2024-10-31 17:46:47',NULL,'ba40f972-f100-408e-9078-34d5c21ff876'),
(30,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-10-31 17:44:20','2024-10-31 17:46:47',NULL,'2024-10-31 17:46:47',NULL,'77e92268-4392-4d8b-9a27-2f0080fbf91c'),
(31,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-10-31 17:44:20','2024-10-31 17:46:47',NULL,'2024-10-31 17:46:47',NULL,'d4e7419b-ef9f-4716-969a-16c1d7f5f358'),
(32,21,NULL,6,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:44:20','2024-10-31 17:44:20',NULL,NULL,NULL,'bb7c95ef-0333-4d6f-b12a-40adae1fe12b'),
(33,27,NULL,7,3,'craft\\elements\\Entry',1,0,'2024-10-31 17:44:20','2024-10-31 17:44:20',NULL,'2024-10-31 17:46:47',NULL,'c3159684-7fcf-440c-bb3e-64c4e9d23dc4'),
(34,30,NULL,8,2,'craft\\elements\\Entry',1,0,'2024-10-31 17:44:20','2024-10-31 17:44:20',NULL,'2024-10-31 17:46:47',NULL,'7a252f43-ead2-4eb2-80f7-3537732ec8a1'),
(35,31,NULL,9,2,'craft\\elements\\Entry',1,0,'2024-10-31 17:44:20','2024-10-31 17:44:20',NULL,'2024-10-31 17:46:47',NULL,'18649837-f38a-48f0-8984-07a2b02cf1ae'),
(45,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-10-31 17:46:45','2024-10-31 17:47:11',NULL,'2024-10-31 17:47:11',NULL,'8b254b7a-edcf-45fa-a77b-745882e5c1da'),
(46,21,NULL,10,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:46:47','2024-10-31 17:46:47',NULL,NULL,NULL,'6aa7b917-e484-488e-981b-8ad976e490ae'),
(47,45,NULL,11,3,'craft\\elements\\Entry',1,0,'2024-10-31 17:46:47','2024-10-31 17:46:47',NULL,'2024-10-31 17:47:11',NULL,'bf7c6123-5bbb-4ef4-963b-77f4988c6c80'),
(49,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-10-31 17:46:50','2024-10-31 17:47:29',NULL,'2024-10-31 17:47:29',NULL,'03a5cbe4-08b1-4faf-82ec-6fbbc730f066'),
(51,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-10-31 17:47:11','2024-10-31 17:47:29',NULL,'2024-10-31 17:47:29',NULL,'c85a4787-1d3f-4d37-b11c-3da47964c732'),
(52,21,NULL,12,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:47:11','2024-10-31 17:47:11',NULL,NULL,NULL,'45e1fd52-ed54-4a5c-80d2-88c070f001a1'),
(53,49,NULL,13,3,'craft\\elements\\Entry',1,0,'2024-10-31 17:47:11','2024-10-31 17:47:11',NULL,'2024-10-31 17:47:29',NULL,'0dbc0f2a-b6bb-406c-b843-cecc5bf44403'),
(54,51,NULL,14,2,'craft\\elements\\Entry',1,0,'2024-10-31 17:47:11','2024-10-31 17:47:11',NULL,'2024-10-31 17:47:29',NULL,'a41ebbb8-aedd-400c-b028-33cd42c06d32'),
(56,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-10-31 17:47:16','2024-10-31 17:47:29',NULL,NULL,NULL,'dfecdb05-c9ef-415e-9430-bad772ee5284'),
(57,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-10-31 17:47:16','2024-10-31 17:47:29',NULL,NULL,NULL,'f69e5af5-b405-4980-968f-f2df81c9ca8d'),
(58,21,NULL,15,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:47:29','2024-10-31 17:47:29',NULL,NULL,NULL,'21401ded-2b1d-4627-9625-cba5401cff65'),
(59,56,NULL,16,3,'craft\\elements\\Entry',1,0,'2024-10-31 17:47:29','2024-10-31 17:47:29',NULL,NULL,NULL,'a195a4a4-8c9e-4566-ad95-e1802e2559cf'),
(60,57,NULL,17,2,'craft\\elements\\Entry',1,0,'2024-10-31 17:47:29','2024-10-31 17:47:29',NULL,NULL,NULL,'dfa737fb-3ed4-424f-a8de-5292ea85029d'),
(61,21,40,NULL,1,'craft\\elements\\Entry',1,0,'2024-10-31 17:47:31','2024-10-31 17:47:40',NULL,NULL,NULL,'28bfa8f4-8187-409d-aef7-4fd8cd0c55c8'),
(62,56,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-10-31 17:47:31','2024-10-31 17:47:40',NULL,NULL,NULL,'803a4e4d-d1cd-4862-918f-0a211c2db1d5');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int(11) NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_kcawsktfjrkymefbmrhghjgffvkzdccyodrw` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_owners` (
  `elementId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_ovkemopduascodhyiizeouekeysvzvllartl` (`ownerId`),
  CONSTRAINT `fk_ovkemopduascodhyiizeouekeysvzvllartl` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sjjuudhijxyjaoctrenpxwrlmzojcfasdwlt` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
INSERT INTO `elements_owners` VALUES
(9,7,2),
(10,9,1),
(11,7,3),
(12,7,4),
(14,13,4),
(20,19,1),
(22,21,1),
(22,61,1),
(23,21,2),
(23,61,2),
(25,24,1),
(27,21,1),
(27,61,1),
(30,21,2),
(30,61,2),
(31,21,3),
(31,61,3),
(33,32,1),
(34,32,2),
(35,32,3),
(45,21,1),
(45,61,1),
(47,46,1),
(49,21,1),
(49,61,1),
(51,21,2),
(51,61,2),
(53,52,1),
(54,52,2),
(56,21,1),
(57,21,2),
(57,61,2),
(59,58,1),
(60,58,2),
(62,61,1);
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`content`)),
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_frluchbgvdozimmezbabktrgisnaokambicg` (`elementId`,`siteId`),
  KEY `idx_chdywumvquzpuepughbojbxgqtdxrfjklhzj` (`siteId`),
  KEY `idx_quamxrmorzvbygpydcgmsinwkjffatekneff` (`title`,`siteId`),
  KEY `idx_bbpsmjlqhupnigegtzgotbbuszoxgszpisso` (`slug`,`siteId`),
  KEY `idx_phqfscohghqkfuhkyhrtmtipqhvndqhuqgmw` (`enabled`),
  KEY `idx_aoepxpvlypehyexwayfrnbcjswdaesoidqya` (`uri`,`siteId`),
  CONSTRAINT `fk_ejdrrdfkbxqkcpvdlnviktvtolrtmurddcoz` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wfjcwrwqeueaqegtchjpkwxwklbbvurulxpq` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES
(1,1,1,NULL,NULL,NULL,NULL,1,'2024-10-31 17:29:17','2024-10-31 17:29:17','eecf85f4-c7b2-441e-b7a6-81e5d02650a0'),
(2,2,1,'Test','test','page/test','{\"8e609db9-7fd0-4064-8e8a-a200a7bcc0d0\":\"asasassadasdasdsdfsdfdsf\",\"74ee7590-9942-4110-9769-7c053c72d749\":false,\"1b7c094c-995b-47e7-be8b-1f55903c2355\":\"dsfsdf\"}',1,'2024-10-31 17:33:30','2024-10-31 17:35:26','b3ee6267-500f-4c18-a96e-d72554ee2639'),
(3,3,1,NULL,'__temp_zdxnoegoapgmqkwdknaxvobtzqbymhmnzjbn','page/__temp_zdxnoegoapgmqkwdknaxvobtzqbymhmnzjbn','{\"74ee7590-9942-4110-9769-7c053c72d749\":false}',1,'2024-10-31 17:33:30','2024-10-31 17:33:30','4f81e0c8-9e30-4a06-94f8-6463e6023903'),
(4,4,1,'Test','test','page/test','{\"74ee7590-9942-4110-9769-7c053c72d749\":false,\"8e609db9-7fd0-4064-8e8a-a200a7bcc0d0\":\"asasassadasdasdsdfsdfdsf\",\"1b7c094c-995b-47e7-be8b-1f55903c2355\":\"dsfsdf\"}',1,'2024-10-31 17:35:26','2024-10-31 17:35:26','187426b7-1f56-47d4-8e43-9bc418d8d4c0'),
(5,5,1,'Test','test','page/test','{\"74ee7590-9942-4110-9769-7c053c72d749\":false,\"8e609db9-7fd0-4064-8e8a-a200a7bcc0d0\":\"asasassadasdasdsdfsdfdsf\",\"1b7c094c-995b-47e7-be8b-1f55903c2355\":\"dsfsdf\"}',1,'2024-10-31 17:36:08','2024-10-31 17:36:08','6e7fb44a-650a-4ec6-8b3a-235d2ef6ba57'),
(6,6,1,NULL,'__temp_fzmbtudtmjkbqufachpqshbevnbgnsumabgn','page/__temp_fzmbtudtmjkbqufachpqshbevnbgnsumabgn','{\"74ee7590-9942-4110-9769-7c053c72d749\":false}',1,'2024-10-31 17:36:13','2024-10-31 17:36:13','6eef1dbc-6ab4-4c5a-9610-c01b23c52c1e'),
(7,7,1,'sdfsdf','sdfsdf','page/sdfsdf',NULL,1,'2024-10-31 17:37:47','2024-10-31 17:39:17','8124cf70-3fa7-4e0f-9a62-518d65794892'),
(9,9,1,'sdfsd','__temp_bcwpsmyugxpbqnxgzbcajofsrqftgcsatfur',NULL,NULL,1,'2024-10-31 17:38:10','2024-10-31 17:38:14','049068a3-89d5-4e24-b487-894ad4d97d2b'),
(10,10,1,NULL,'__temp_axvukrieidfqpfherbkqvptnjmjtvoqqemmm',NULL,NULL,1,'2024-10-31 17:38:14','2024-10-31 17:38:14','3c3afe2a-ae56-44f3-8919-c47c411b292e'),
(11,11,1,NULL,'__temp_vonfvgtmwztvpdfmlnmgmrzpihdmkuzvicpc',NULL,NULL,1,'2024-10-31 17:39:17','2024-10-31 17:39:17','ab95f1e0-052d-47ac-b1e4-37d9b93d324c'),
(12,12,1,'Titre','titre',NULL,'{\"2c11b749-28b5-4aec-bb90-85031716810f\":true,\"ec2e6634-a421-41f8-a7ec-82dec4cb7f13\":\"asdasdasd\"}',1,'2024-10-31 17:39:23','2024-10-31 17:39:32','71ac12b0-da84-4f16-9c27-ac4bab4a8959'),
(13,13,1,'sdfsdf','sdfsdf','page/sdfsdf',NULL,1,'2024-10-31 17:39:39','2024-10-31 17:39:39','28e186c7-3070-4272-9c0f-2b856b3cc2e5'),
(14,14,1,'Titre','titre',NULL,'{\"2c11b749-28b5-4aec-bb90-85031716810f\":true,\"ec2e6634-a421-41f8-a7ec-82dec4cb7f13\":\"asdasdasd\"}',1,'2024-10-31 17:39:39','2024-10-31 17:39:39','554d1642-3c49-4350-9ab4-8a28a22f89ef'),
(17,17,1,NULL,'__temp_iucflxngkmhbuyrjzhnunztvpmmwjjremyom',NULL,NULL,1,'2024-10-31 17:39:59','2024-10-31 17:39:59','882b2de7-55ea-448a-9ba2-12754a030c63'),
(19,19,1,NULL,'__temp_ilbnemxezlecaqyhnzlaxhyjyndgbnfmfecy','page/__temp_ilbnemxezlecaqyhnzlaxhyjyndgbnfmfecy',NULL,1,'2024-10-31 17:42:23','2024-10-31 17:43:25','1a9a8a1f-85df-4cbd-9285-53482eb0ac90'),
(20,20,1,NULL,'__temp_qsfztirtxgeszcqwqujcjktjfccnekspmwaz',NULL,'{\"2c11b749-28b5-4aec-bb90-85031716810f\":false}',1,'2024-10-31 17:42:26','2024-10-31 17:43:25','7ff1d675-e0d8-4b97-8dec-8df17310b646'),
(21,21,1,'Test','test-2','page/test-2',NULL,1,'2024-10-31 17:43:28','2024-10-31 17:43:32','6f0c85f3-83f7-4d92-9488-4772a047f44d'),
(22,22,1,'sdfsdf','sdfsdf',NULL,'{\"2c11b749-28b5-4aec-bb90-85031716810f\":false,\"ec2e6634-a421-41f8-a7ec-82dec4cb7f13\":\"test\"}',1,'2024-10-31 17:43:32','2024-10-31 17:43:40','290ea8e3-34d5-4683-ac6d-3589b6dd8129'),
(23,23,1,NULL,'__temp_ewosfcaiyxxwmhzgeybjgpqwwwkwcagnptym',NULL,NULL,1,'2024-10-31 17:43:43','2024-10-31 17:43:43','4da12432-f85b-4e44-8f28-7552554d2bb4'),
(24,24,1,'Test','test-2','page/test-2',NULL,1,'2024-10-31 17:43:55','2024-10-31 17:43:55','bcb15aa1-4077-414c-8bc3-3cec9a6883e8'),
(25,25,1,'sdfsdf','sdfsdf',NULL,'{\"2c11b749-28b5-4aec-bb90-85031716810f\":false,\"ec2e6634-a421-41f8-a7ec-82dec4cb7f13\":\"test\"}',1,'2024-10-31 17:43:55','2024-10-31 17:43:55','c9b42574-9d35-45fa-89fd-0b22f2e1e58c'),
(27,27,1,'sdfsdf','sdfsdf',NULL,'{\"2c11b749-28b5-4aec-bb90-85031716810f\":true,\"ec2e6634-a421-41f8-a7ec-82dec4cb7f13\":\"test\"}',1,'2024-10-31 17:44:00','2024-10-31 17:44:00','4b58ce8c-6615-4038-a07b-c1c449e3e83e'),
(30,30,1,'2','2',NULL,'{\"3ebf00a1-282f-4396-94c8-ee67edeb306d\":\"2\"}',1,'2024-10-31 17:44:20','2024-10-31 17:44:20','328d0b05-16cc-4c01-be71-15b44fe52e42'),
(31,31,1,'1','1',NULL,'{\"3ebf00a1-282f-4396-94c8-ee67edeb306d\":\"1\"}',1,'2024-10-31 17:44:20','2024-10-31 17:44:20','fe33bce9-1f88-41cb-8a39-16cc0a5fa708'),
(32,32,1,'Test','test-2','page/test-2',NULL,1,'2024-10-31 17:44:20','2024-10-31 17:44:20','98285918-8b67-4ff3-8a46-63b54f17b200'),
(33,33,1,'sdfsdf','sdfsdf',NULL,'{\"2c11b749-28b5-4aec-bb90-85031716810f\":true,\"ec2e6634-a421-41f8-a7ec-82dec4cb7f13\":\"test\"}',1,'2024-10-31 17:44:20','2024-10-31 17:44:20','33f3d1b8-5a02-4fdf-988b-569516502656'),
(34,34,1,'2','2',NULL,'{\"3ebf00a1-282f-4396-94c8-ee67edeb306d\":\"2\"}',1,'2024-10-31 17:44:20','2024-10-31 17:44:20','5bdfe3fa-967f-4181-9a31-f05b425fec95'),
(35,35,1,'1','1',NULL,'{\"3ebf00a1-282f-4396-94c8-ee67edeb306d\":\"1\"}',1,'2024-10-31 17:44:20','2024-10-31 17:44:20','c75db693-fa8a-4090-b5f6-c52ec81e19b9'),
(45,45,1,'sdfsdf','sdfsdf',NULL,'{\"2c11b749-28b5-4aec-bb90-85031716810f\":false,\"ec2e6634-a421-41f8-a7ec-82dec4cb7f13\":\"test\"}',1,'2024-10-31 17:46:45','2024-10-31 17:46:45','bc470bfb-74a4-4597-a1e3-650da738eaca'),
(46,46,1,'Test','test-2','page/test-2',NULL,1,'2024-10-31 17:46:47','2024-10-31 17:46:47','16fc397b-cf7f-400e-a39a-8ea474586272'),
(47,47,1,'sdfsdf','sdfsdf',NULL,'{\"2c11b749-28b5-4aec-bb90-85031716810f\":false,\"ec2e6634-a421-41f8-a7ec-82dec4cb7f13\":\"test\"}',1,'2024-10-31 17:46:47','2024-10-31 17:46:47','f968c76b-bb89-4774-aba7-54af2e9faee9'),
(49,49,1,'sdfsdf','sdfsdf',NULL,'{\"2c11b749-28b5-4aec-bb90-85031716810f\":true,\"ec2e6634-a421-41f8-a7ec-82dec4cb7f13\":\"aaaa\",\"e571706a-c7ac-4419-b935-b7148454c8f1\":\"werwerwer\"}',1,'2024-10-31 17:46:50','2024-10-31 17:47:09','97ee5690-d640-493a-b075-1c2488cd4f63'),
(51,51,1,'sdf','sdf',NULL,'{\"3ebf00a1-282f-4396-94c8-ee67edeb306d\":\"werwersfsdf\"}',1,'2024-10-31 17:47:11','2024-10-31 17:47:11','235ed527-e028-43eb-89b3-916903dce4c8'),
(52,52,1,'Test','test-2','page/test-2',NULL,1,'2024-10-31 17:47:11','2024-10-31 17:47:11','9cd9f85b-7683-480e-9b4d-1201520af718'),
(53,53,1,'sdfsdf','sdfsdf',NULL,'{\"2c11b749-28b5-4aec-bb90-85031716810f\":true,\"e571706a-c7ac-4419-b935-b7148454c8f1\":\"werwerwer\",\"ec2e6634-a421-41f8-a7ec-82dec4cb7f13\":\"aaaa\"}',1,'2024-10-31 17:47:11','2024-10-31 17:47:11','f1bd8420-973b-4319-a21f-c8a700f9186c'),
(54,54,1,'sdf','sdf',NULL,'{\"3ebf00a1-282f-4396-94c8-ee67edeb306d\":\"werwersfsdf\"}',1,'2024-10-31 17:47:11','2024-10-31 17:47:11','d49f8f69-b295-46b1-85ee-4ba2b5590b87'),
(56,56,1,'sdfsdf','sdfsdf',NULL,'{\"2c11b749-28b5-4aec-bb90-85031716810f\":true,\"ec2e6634-a421-41f8-a7ec-82dec4cb7f13\":\"on\",\"e571706a-c7ac-4419-b935-b7148454c8f1\":\"off\"}',1,'2024-10-31 17:47:16','2024-10-31 17:47:26','3e31cc57-3893-4d2d-b51e-8d652532881e'),
(57,57,1,'sdfsdf','sdf',NULL,'{\"3ebf00a1-282f-4396-94c8-ee67edeb306d\":\"textonly\"}',1,'2024-10-31 17:47:16','2024-10-31 17:47:29','5f51830b-c4ea-4390-a513-7087fb0fafa0'),
(58,58,1,'Test','test-2','page/test-2',NULL,1,'2024-10-31 17:47:29','2024-10-31 17:47:29','f3603357-4bc0-4ad2-b498-d6d2167ccf68'),
(59,59,1,'sdfsdf','sdfsdf',NULL,'{\"2c11b749-28b5-4aec-bb90-85031716810f\":true,\"e571706a-c7ac-4419-b935-b7148454c8f1\":\"off\",\"ec2e6634-a421-41f8-a7ec-82dec4cb7f13\":\"on\"}',1,'2024-10-31 17:47:29','2024-10-31 17:47:29','9e654ca3-9f1e-48a8-bfb7-f0f54935d43b'),
(60,60,1,'sdfsdf','sdf',NULL,'{\"3ebf00a1-282f-4396-94c8-ee67edeb306d\":\"textonly\"}',1,'2024-10-31 17:47:29','2024-10-31 17:47:29','7df54a26-3d89-4807-ade4-ad15a54a1590'),
(61,61,1,'Test','test-2','page/test-2',NULL,1,'2024-10-31 17:47:31','2024-10-31 17:47:31','c269b5b5-644c-480c-9837-e00a6412b8ce'),
(62,62,1,'sdfsdf','sdfsdf',NULL,'{\"2c11b749-28b5-4aec-bb90-85031716810f\":false,\"ec2e6634-a421-41f8-a7ec-82dec4cb7f13\":\"on\",\"e571706a-c7ac-4419-b935-b7148454c8f1\":\"off\"}',1,'2024-10-31 17:47:31','2024-10-31 17:47:40','fcd0e7ae-6f03-4175-8502-df2a5d55b04d');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) DEFAULT NULL,
  `parentId` int(11) DEFAULT NULL,
  `primaryOwnerId` int(11) DEFAULT NULL,
  `fieldId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_xxcykomgvlsejmtahapbvdvagtabdtjnrdjq` (`postDate`),
  KEY `idx_hzyttqycbbswgzypcunpptepshbxoxeahtri` (`expiryDate`),
  KEY `idx_svkcgiuoujtlojoefwnwjnzhzjraqlwmjeip` (`sectionId`),
  KEY `idx_vtufxvzrrmocqqkdnxoybrqwmhggqbdvprbt` (`typeId`),
  KEY `idx_exteqvexomeudeahgaiedjzyqntqfiuttuid` (`primaryOwnerId`),
  KEY `idx_behwojacgcyczvrqppaehqebrunntocmtcjr` (`fieldId`),
  KEY `fk_lwqibadumnhxrtyvryxjnjenswcgznybftfs` (`parentId`),
  CONSTRAINT `fk_icjkicjnognmdbtjqijweyrlodeftzwbmpnx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jnyzjiaxdcuqhfnmkeyjxavgzobqmoxmfbct` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_krwmlxpydsxlmczxkekskkgmsypismuwevlv` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lwqibadumnhxrtyvryxjnjenswcgznybftfs` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_olodgxtzitwnxqdtmgclytsjwmfzvrlkucqt` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xydgfwotkmxahdbpropfvmvfvmutwhbeihqw` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES
(2,1,NULL,NULL,NULL,1,'2024-10-31 17:35:00',NULL,NULL,'2024-10-31 17:33:30','2024-10-31 17:35:26'),
(3,1,NULL,NULL,NULL,1,'2024-10-31 17:33:30',NULL,NULL,'2024-10-31 17:33:30','2024-10-31 17:33:30'),
(4,1,NULL,NULL,NULL,1,'2024-10-31 17:35:00',NULL,NULL,'2024-10-31 17:35:26','2024-10-31 17:35:26'),
(5,1,NULL,NULL,NULL,1,'2024-10-31 17:35:00',NULL,NULL,'2024-10-31 17:36:08','2024-10-31 17:36:08'),
(6,1,NULL,NULL,NULL,1,'2024-10-31 17:36:13',NULL,NULL,'2024-10-31 17:36:13','2024-10-31 17:36:13'),
(7,1,NULL,NULL,NULL,1,'2024-10-31 17:39:00',NULL,NULL,'2024-10-31 17:37:47','2024-10-31 17:39:39'),
(9,NULL,NULL,7,4,1,NULL,NULL,0,'2024-10-31 17:38:10','2024-10-31 17:38:10'),
(10,NULL,NULL,9,4,1,NULL,NULL,NULL,'2024-10-31 17:38:14','2024-10-31 17:38:14'),
(11,NULL,NULL,7,4,2,NULL,NULL,NULL,'2024-10-31 17:39:17','2024-10-31 17:39:17'),
(12,NULL,NULL,7,4,3,'2024-10-31 17:39:00',NULL,NULL,'2024-10-31 17:39:23','2024-10-31 17:39:32'),
(13,1,NULL,NULL,NULL,1,'2024-10-31 17:39:00',NULL,NULL,'2024-10-31 17:39:39','2024-10-31 17:39:39'),
(14,NULL,NULL,13,4,3,'2024-10-31 17:39:00',NULL,NULL,'2024-10-31 17:39:39','2024-10-31 17:39:39'),
(19,1,NULL,NULL,NULL,1,'2024-10-31 17:42:23',NULL,NULL,'2024-10-31 17:42:23','2024-10-31 17:42:23'),
(20,NULL,NULL,19,4,3,'2024-10-31 17:43:00',NULL,NULL,'2024-10-31 17:42:26','2024-10-31 17:43:17'),
(21,1,NULL,NULL,NULL,1,'2024-10-31 17:43:00',NULL,NULL,'2024-10-31 17:43:28','2024-10-31 17:43:55'),
(22,NULL,NULL,21,4,3,'2024-10-31 17:43:00',NULL,0,'2024-10-31 17:43:32','2024-10-31 17:43:33'),
(23,NULL,NULL,21,4,2,'2024-10-31 17:43:00',NULL,0,'2024-10-31 17:43:43','2024-10-31 17:43:43'),
(24,1,NULL,NULL,NULL,1,'2024-10-31 17:43:00',NULL,NULL,'2024-10-31 17:43:55','2024-10-31 17:43:55'),
(25,NULL,NULL,24,4,3,'2024-10-31 17:43:00',NULL,NULL,'2024-10-31 17:43:55','2024-10-31 17:43:55'),
(27,NULL,NULL,21,4,3,'2024-10-31 17:43:00',NULL,0,'2024-10-31 17:44:00','2024-10-31 17:44:20'),
(30,NULL,NULL,21,4,2,'2024-10-31 17:44:00',NULL,0,'2024-10-31 17:44:20','2024-10-31 17:44:20'),
(31,NULL,NULL,21,4,2,'2024-10-31 17:44:00',NULL,0,'2024-10-31 17:44:20','2024-10-31 17:44:20'),
(32,1,NULL,NULL,NULL,1,'2024-10-31 17:43:00',NULL,NULL,'2024-10-31 17:44:20','2024-10-31 17:44:20'),
(33,NULL,NULL,32,4,3,'2024-10-31 17:43:00',NULL,NULL,'2024-10-31 17:44:20','2024-10-31 17:44:20'),
(34,NULL,NULL,32,4,2,'2024-10-31 17:44:00',NULL,NULL,'2024-10-31 17:44:20','2024-10-31 17:44:20'),
(35,NULL,NULL,32,4,2,'2024-10-31 17:44:00',NULL,NULL,'2024-10-31 17:44:20','2024-10-31 17:44:20'),
(45,NULL,NULL,21,4,3,'2024-10-31 17:43:00',NULL,0,'2024-10-31 17:46:45','2024-10-31 17:46:47'),
(46,1,NULL,NULL,NULL,1,'2024-10-31 17:43:00',NULL,NULL,'2024-10-31 17:46:47','2024-10-31 17:46:47'),
(47,NULL,NULL,46,4,3,'2024-10-31 17:43:00',NULL,NULL,'2024-10-31 17:46:47','2024-10-31 17:46:47'),
(49,NULL,NULL,21,4,3,'2024-10-31 17:43:00',NULL,0,'2024-10-31 17:46:50','2024-10-31 17:47:11'),
(51,NULL,NULL,21,4,2,'2024-10-31 17:46:00',NULL,0,'2024-10-31 17:47:11','2024-10-31 17:47:11'),
(52,1,NULL,NULL,NULL,1,'2024-10-31 17:43:00',NULL,NULL,'2024-10-31 17:47:11','2024-10-31 17:47:11'),
(53,NULL,NULL,52,4,3,'2024-10-31 17:43:00',NULL,NULL,'2024-10-31 17:47:11','2024-10-31 17:47:11'),
(54,NULL,NULL,52,4,2,'2024-10-31 17:46:00',NULL,NULL,'2024-10-31 17:47:11','2024-10-31 17:47:11'),
(56,NULL,NULL,21,4,3,'2024-10-31 17:43:00',NULL,NULL,'2024-10-31 17:47:16','2024-10-31 17:47:29'),
(57,NULL,NULL,21,4,2,'2024-10-31 17:46:00',NULL,NULL,'2024-10-31 17:47:16','2024-10-31 17:47:29'),
(58,1,NULL,NULL,NULL,1,'2024-10-31 17:43:00',NULL,NULL,'2024-10-31 17:47:29','2024-10-31 17:47:29'),
(59,NULL,NULL,58,4,3,'2024-10-31 17:43:00',NULL,NULL,'2024-10-31 17:47:29','2024-10-31 17:47:29'),
(60,NULL,NULL,58,4,2,'2024-10-31 17:46:00',NULL,NULL,'2024-10-31 17:47:29','2024-10-31 17:47:29'),
(61,1,NULL,NULL,NULL,1,'2024-10-31 17:43:00',NULL,NULL,'2024-10-31 17:47:31','2024-10-31 17:47:31'),
(62,NULL,NULL,61,4,3,'2024-10-31 17:43:00',NULL,NULL,'2024-10-31 17:47:31','2024-10-31 17:47:31');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries_authors` (
  `entryId` int(11) NOT NULL,
  `authorId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_zkixkkrrqugvummkmvvnmsnqgawrovxqcsjn` (`authorId`),
  KEY `idx_vbqqjndkesfoydjyzboswydeilwsnwmmttqi` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_hvwzujvuavlxzcskugfjhehgzclexhguztwn` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jxvikunkrwydzexflgdrevpaijzwqotfmumv` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
INSERT INTO `entries_authors` VALUES
(2,1,1),
(3,1,1),
(4,1,1),
(5,1,1),
(6,1,1),
(7,1,1),
(13,1,1),
(19,1,1),
(21,1,1),
(24,1,1),
(32,1,1),
(46,1,1),
(52,1,1),
(58,1,1),
(61,1,1);
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT 1,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT 1,
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text DEFAULT NULL,
  `showStatusField` tinyint(1) DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yyovigzlhageepzgtaspqzrwycyogwfiphqu` (`fieldLayoutId`),
  KEY `idx_xbqkuhtzfeupynedbrgyxeiyazbgdvldeqqg` (`dateDeleted`),
  CONSTRAINT `fk_ecjgcdkcahsezdiidbesyqosssqiuppxeuyl` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES
(1,1,'Default','default','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-10-31 17:33:23','2024-10-31 17:33:23',NULL,'de1bee1c-fb26-4274-8430-e7db93649807'),
(2,2,'Text only','textonly','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-10-31 17:37:31','2024-10-31 17:38:37',NULL,'edf4e300-3145-4f61-908d-262ea02dcaa4'),
(3,3,'Condtional','condtional','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-10-31 17:39:01','2024-10-31 17:39:01',NULL,'541b2121-af3f-4576-a1a9-bb7a9a50d0b3');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config`)),
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vruistdouhofstnygskyvlupxoksxphbobbe` (`dateDeleted`),
  KEY `idx_wmnjuauclwpgwicudlpmmbopaepamolvuufq` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES
(1,'craft\\elements\\Entry','{\"tabs\":[{\"name\":\"Content\",\"uid\":\"4c09b3a2-901b-451a-9628-0cbc3719184e\",\"userCondition\":null,\"elementCondition\":null,\"elements\":[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"providesThumbs\":false,\"includeInCards\":false,\"width\":100,\"dateAdded\":\"2024-10-31T17:30:17+00:00\",\"uid\":\"cd7e8f86-0938-4f6a-a84c-6bf2a617f4d7\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"handle\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"providesThumbs\":false,\"includeInCards\":false,\"width\":100,\"dateAdded\":\"2024-10-31T17:38:00+00:00\",\"uid\":\"1e8b1505-ded4-4d74-a21f-79ebb195b524\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"e6df5007-e040-4014-b74c-6addcb50730a\"}]}]}','2024-10-31 17:33:23','2024-10-31 17:38:00',NULL,'7e96a501-803e-4677-b1d0-b31de1a32bb7'),
(2,'craft\\elements\\Entry','{\"tabs\":[{\"name\":\"Content\",\"uid\":\"cbd20e82-4895-4185-a26c-d5f8b9d5939a\",\"userCondition\":null,\"elementCondition\":null,\"elements\":[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"providesThumbs\":false,\"includeInCards\":false,\"width\":100,\"dateAdded\":\"2024-10-31T17:36:17+00:00\",\"uid\":\"538ab32d-4776-43c9-b5b1-307223dbccb3\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"handle\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"providesThumbs\":false,\"includeInCards\":false,\"width\":100,\"dateAdded\":\"2024-10-31T17:37:31+00:00\",\"uid\":\"3ebf00a1-282f-4396-94c8-ee67edeb306d\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"adc0d524-01bd-4bb3-8f35-ba91943efb90\"}]}]}','2024-10-31 17:37:31','2024-10-31 17:37:31',NULL,'b2bff3e5-12ee-4726-a791-25ede9062c3b'),
(3,'craft\\elements\\Entry','{\"tabs\":[{\"name\":\"Content\",\"uid\":\"5fcbd4fd-8424-414d-abfe-9506d060e045\",\"userCondition\":null,\"elementCondition\":null,\"elements\":[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"providesThumbs\":false,\"includeInCards\":false,\"width\":100,\"dateAdded\":\"2024-10-31T17:37:39+00:00\",\"uid\":\"c89b093b-b78f-40d5-a56e-3c87539ff489\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"handle\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"providesThumbs\":false,\"includeInCards\":false,\"width\":100,\"dateAdded\":\"2024-10-31T17:39:01+00:00\",\"uid\":\"2c11b749-28b5-4aec-bb90-85031716810f\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"da714b55-a04c-4269-85fd-7ab743a0bf2b\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"handle\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"providesThumbs\":false,\"includeInCards\":false,\"width\":100,\"dateAdded\":\"2024-10-31T17:39:01+00:00\",\"uid\":\"e571706a-c7ac-4419-b935-b7148454c8f1\",\"userCondition\":null,\"elementCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\",\"conditionRules\":[{\"class\":\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\",\"uid\":\"ad507292-f948-4480-bf6e-0542ed53d336\",\"value\":false,\"fieldUid\":\"da714b55-a04c-4269-85fd-7ab743a0bf2b\",\"layoutElementUid\":\"2c11b749-28b5-4aec-bb90-85031716810f\"}]},\"fieldUid\":\"4528f321-cffc-46ae-b89a-8b6956271988\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"handle\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"providesThumbs\":false,\"includeInCards\":false,\"width\":100,\"dateAdded\":\"2024-10-31T17:39:01+00:00\",\"uid\":\"ec2e6634-a421-41f8-a7ec-82dec4cb7f13\",\"userCondition\":null,\"elementCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\",\"conditionRules\":[{\"class\":\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\",\"uid\":\"7294f5c0-1ec7-4c77-8795-f1131ac35fac\",\"value\":true,\"fieldUid\":\"da714b55-a04c-4269-85fd-7ab743a0bf2b\",\"layoutElementUid\":\"2c11b749-28b5-4aec-bb90-85031716810f\"}]},\"fieldUid\":\"adc0d524-01bd-4bb3-8f35-ba91943efb90\"}]}]}','2024-10-31 17:39:01','2024-10-31 17:39:01',NULL,'b20620a5-d578-4c78-998e-705918673889');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `searchable` tinyint(1) NOT NULL DEFAULT 1,
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_iymaupzjfxnbevbdusomaysthvnreyuhhdmo` (`handle`,`context`),
  KEY `idx_qogdiqdqcfkiebjafnsiuyhxaulnpuwkgjyz` (`context`),
  KEY `idx_ecyaykhorhqogvyxnzdfqjiqsbwikfcozzrk` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES
(1,'Switch','switch','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Lightswitch','{\"default\":false,\"offLabel\":\"OFF\",\"onLabel\":\"ON\"}','2024-10-31 17:32:19','2024-10-31 17:32:19',NULL,'da714b55-a04c-4269-85fd-7ab743a0bf2b'),
(2,'Text OFF','textOff','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-10-31 17:32:34','2024-10-31 17:32:34',NULL,'4528f321-cffc-46ae-b89a-8b6956271988'),
(3,'Text ON','textOn','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-10-31 17:32:45','2024-10-31 17:32:45',NULL,'adc0d524-01bd-4bb3-8f35-ba91943efb90'),
(4,'Matrix','matrix','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":null,\"entryTypes\":[\"edf4e300-3145-4f61-908d-262ea02dcaa4\",\"541b2121-af3f-4576-a1a9-bb7a9a50d0b3\"],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":null,\"pageSize\":null,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"blocks\"}','2024-10-31 17:37:32','2024-10-31 17:40:18',NULL,'e6df5007-e040-4014-b74c-6addcb50730a');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wwpqoicbnxomhdoomhrvwjqrricrjjjkhndr` (`name`),
  KEY `idx_jzrxhncyehushvvqgswkdsouhfidivbwnhir` (`handle`),
  KEY `idx_wwkxsdsnpllczstidfvoatgtczetnhccpirz` (`fieldLayoutId`),
  KEY `idx_kcalnjnxybnnhxxsjkcvufcahslquuywflvu` (`sortOrder`),
  CONSTRAINT `fk_apkffmgcwpofubxbpuknsxocnwotqklzbjwd` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_typppptlfqapbwxylipzjalztyhdzzpyxrac` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqlschemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`scope`)),
  `isPublic` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqltokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vehtbhbbfdrikanuswakfteknzieuxqyxatz` (`accessToken`),
  UNIQUE KEY `idx_bccfzqdixedbbqvgqexomgndzxdzehuaxmny` (`name`),
  KEY `fk_gbflvpsdoxonigppeoaiivrsvkujkebvddge` (`schemaId`),
  CONSTRAINT `fk_gbflvpsdoxonigppeoaiivrsvkujkebvddge` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT 0,
  `inProgress` tinyint(1) NOT NULL DEFAULT 0,
  `error` tinyint(1) NOT NULL DEFAULT 0,
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_psacdieqyhhynoywpxnamdekqmsosaoirdhi` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT 1,
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bzifvktrqzonwtaowgguigughidpbrsdmoyz` (`name`),
  KEY `idx_hmmttytfsnpusrymucfxvetyvjoxrkkfeghj` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT 0,
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES
(1,'5.4.9','5.3.0.2',0,'sfbmhlvrantp','3@beuxakhugu','2024-10-31 17:29:16','2024-10-31 17:40:18','989f7398-d250-4da2-aba4-759c5293505a');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hoonyzbanhfvuybfpffdytvsxpqsacoltnzk` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'craft','Install','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','75656ff3-7f01-4ef4-8f89-e6f45b0a2879'),
(2,'craft','m221101_115859_create_entries_authors_table','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','d765a356-2380-4124-9ac6-113f76f3e01c'),
(3,'craft','m221107_112121_add_max_authors_to_sections','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','cc887cc8-115d-4d33-ada8-ad9745833120'),
(4,'craft','m221205_082005_translatable_asset_alt_text','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','e51b6af9-6c16-4028-b501-400e276093b2'),
(5,'craft','m230314_110309_add_authenticator_table','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','4a6dac97-0f7c-4a8d-a78f-499ac74514dc'),
(6,'craft','m230314_111234_add_webauthn_table','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','78033469-fc3e-4dc5-968b-f329f4490fe9'),
(7,'craft','m230503_120303_add_recoverycodes_table','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','29c704c3-9aa3-4bb5-9ff3-63dbf2cf10c9'),
(8,'craft','m230511_000000_field_layout_configs','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','9b813512-c79d-4d01-ab76-70f8bad24994'),
(9,'craft','m230511_215903_content_refactor','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','54dac5c8-0c9b-4f21-984d-949d235cdeef'),
(10,'craft','m230524_000000_add_entry_type_show_slug_field','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','0ffa0523-72f6-4169-952b-4089a1cddc06'),
(11,'craft','m230524_000001_entry_type_icons','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','c32dee65-e919-4cf8-bb0d-b0fe118e540c'),
(12,'craft','m230524_000002_entry_type_colors','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','e5f60737-3c6d-47a0-a540-c816b1c38c35'),
(13,'craft','m230524_220029_global_entry_types','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','0456bcba-1f57-4c90-ac57-302fd95d15e6'),
(14,'craft','m230531_123004_add_entry_type_show_status_field','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','3655df7c-cafb-4a9a-91a9-8e8dcfa1cf3b'),
(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','04a36c98-a626-413e-a8f1-16cd83e42118'),
(16,'craft','m230616_173810_kill_field_groups','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','93b10a92-43af-44cd-b48f-818c72641e1d'),
(17,'craft','m230616_183820_remove_field_name_limit','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','ddcfb4fe-c375-492e-8369-f0547c35065c'),
(18,'craft','m230617_070415_entrify_matrix_blocks','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','e9b43c46-87cf-4915-9b35-aff071d591ef'),
(19,'craft','m230710_162700_element_activity','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','789c82f1-2072-498e-bc71-f9e58cc3b19c'),
(20,'craft','m230820_162023_fix_cache_id_type','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','34448c4b-073d-4a0f-a2a1-7d95e4ae2a99'),
(21,'craft','m230826_094050_fix_session_id_type','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','d0d5c4e9-10a5-4632-810a-fb2ab7c17956'),
(22,'craft','m230904_190356_address_fields','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','a1264d12-97d5-458b-8477-decd7a4192cb'),
(23,'craft','m230928_144045_add_subpath_to_volumes','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','2b785998-76c3-4b05-9251-5831f5bfd1f1'),
(24,'craft','m231013_185640_changedfields_amend_primary_key','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','c9c4a327-863f-497b-afbe-7a8d7270e9ca'),
(25,'craft','m231213_030600_element_bulk_ops','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','02542500-814b-4f05-aa4e-9e4e093f4331'),
(26,'craft','m240129_150719_sites_language_amend_length','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','9d340ab0-6732-4d73-9f56-9398905a0cb2'),
(27,'craft','m240206_035135_convert_json_columns','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','01f4543e-867c-485b-ac2a-3a50e81240dc'),
(28,'craft','m240207_182452_address_line_3','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','b89cd86f-49d6-4ba6-a0ae-3aa58c6ef7c0'),
(29,'craft','m240302_212719_solo_preview_targets','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','fda02843-3be5-4ae5-9acc-64a0d0ce6c5a'),
(30,'craft','m240619_091352_add_auth_2fa_timestamp','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','1bfdfbcb-358b-4db6-afb6-ed68fef4d24b'),
(31,'craft','m240723_214330_drop_bulkop_fk','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','fe1e9165-608c-4b8d-a47e-3d8e357ca644'),
(32,'craft','m240731_053543_soft_delete_fields','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','3f9ab5c5-1205-427d-8e4c-d56daae5df58'),
(33,'craft','m240805_154041_sso_identities','2024-10-31 17:29:18','2024-10-31 17:29:18','2024-10-31 17:29:18','d305f857-85c2-4de8-9ac7-a19dd40f135a');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kovkbxfyocbtltwfxmdafovfewfxrvvlqpho` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES
('dateModified','1730396418'),
('email.fromEmail','\"support@akufen.ca\"'),
('email.fromName','\"Test bug craft\"'),
('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.color','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elementCondition','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.autocomplete','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.autocorrect','true'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.class','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.dateAdded','\"2024-10-31T17:37:39+00:00\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.disabled','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.elementCondition','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.id','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.includeInCards','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.inputType','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.instructions','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.label','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.max','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.min','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.name','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.orientation','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.placeholder','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.readonly','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.requirable','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.size','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.step','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.tip','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.title','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.uid','\"c89b093b-b78f-40d5-a56e-3c87539ff489\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.userCondition','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.warning','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.0.width','100'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.1.dateAdded','\"2024-10-31T17:39:01+00:00\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.1.elementCondition','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.1.fieldUid','\"da714b55-a04c-4269-85fd-7ab743a0bf2b\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.1.handle','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.1.includeInCards','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.1.instructions','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.1.label','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.1.providesThumbs','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.1.required','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.1.tip','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.1.uid','\"2c11b749-28b5-4aec-bb90-85031716810f\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.1.userCondition','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.1.warning','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.1.width','100'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.dateAdded','\"2024-10-31T17:39:01+00:00\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.elementCondition.class','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.elementCondition.conditionRules.0.class','\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.elementCondition.conditionRules.0.fieldUid','\"da714b55-a04c-4269-85fd-7ab743a0bf2b\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.elementCondition.conditionRules.0.layoutElementUid','\"2c11b749-28b5-4aec-bb90-85031716810f\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.elementCondition.conditionRules.0.uid','\"ad507292-f948-4480-bf6e-0542ed53d336\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.elementCondition.conditionRules.0.value','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.elementCondition.elementType','\"craft\\\\elements\\\\Entry\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.elementCondition.fieldContext','\"global\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.fieldUid','\"4528f321-cffc-46ae-b89a-8b6956271988\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.handle','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.includeInCards','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.instructions','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.label','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.providesThumbs','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.required','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.tip','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.uid','\"e571706a-c7ac-4419-b935-b7148454c8f1\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.userCondition','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.warning','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.2.width','100'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.dateAdded','\"2024-10-31T17:39:01+00:00\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.elementCondition.class','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.elementCondition.conditionRules.0.class','\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.elementCondition.conditionRules.0.fieldUid','\"da714b55-a04c-4269-85fd-7ab743a0bf2b\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.elementCondition.conditionRules.0.layoutElementUid','\"2c11b749-28b5-4aec-bb90-85031716810f\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.elementCondition.conditionRules.0.uid','\"7294f5c0-1ec7-4c77-8795-f1131ac35fac\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.elementCondition.conditionRules.0.value','true'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.elementCondition.elementType','\"craft\\\\elements\\\\Entry\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.elementCondition.fieldContext','\"global\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.fieldUid','\"adc0d524-01bd-4bb3-8f35-ba91943efb90\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.handle','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.includeInCards','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.instructions','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.label','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.providesThumbs','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.required','false'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.tip','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.uid','\"ec2e6634-a421-41f8-a7ec-82dec4cb7f13\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.userCondition','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.warning','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.elements.3.width','100'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.name','\"Content\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.uid','\"5fcbd4fd-8424-414d-abfe-9506d060e045\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.fieldLayouts.b20620a5-d578-4c78-998e-705918673889.tabs.0.userCondition','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.handle','\"condtional\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.hasTitleField','true'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.icon','\"\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.name','\"Condtional\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.showSlugField','true'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.showStatusField','true'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.slugTranslationKeyFormat','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.slugTranslationMethod','\"site\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.titleFormat','\"\"'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.titleTranslationKeyFormat','null'),
('entryTypes.541b2121-af3f-4576-a1a9-bb7a9a50d0b3.titleTranslationMethod','\"site\"'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.color','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elementCondition','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.autocomplete','false'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.autocorrect','true'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.class','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.dateAdded','\"2024-10-31T17:30:17+00:00\"'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.disabled','false'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.elementCondition','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.id','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.includeInCards','false'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.inputType','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.instructions','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.label','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.max','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.min','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.name','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.orientation','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.placeholder','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.readonly','false'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.requirable','false'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.size','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.step','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.tip','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.title','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.uid','\"cd7e8f86-0938-4f6a-a84c-6bf2a617f4d7\"'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.userCondition','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.warning','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.0.width','100'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.1.dateAdded','\"2024-10-31T17:38:00+00:00\"'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.1.elementCondition','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.1.fieldUid','\"e6df5007-e040-4014-b74c-6addcb50730a\"'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.1.handle','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.1.includeInCards','false'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.1.instructions','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.1.label','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.1.providesThumbs','false'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.1.required','false'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.1.tip','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.1.uid','\"1e8b1505-ded4-4d74-a21f-79ebb195b524\"'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.1.userCondition','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.1.warning','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.elements.1.width','100'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.name','\"Content\"'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.uid','\"4c09b3a2-901b-451a-9628-0cbc3719184e\"'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.fieldLayouts.7e96a501-803e-4677-b1d0-b31de1a32bb7.tabs.0.userCondition','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.handle','\"default\"'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.hasTitleField','true'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.icon','\"\"'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.name','\"Default\"'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.showSlugField','true'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.showStatusField','true'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.slugTranslationKeyFormat','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.slugTranslationMethod','\"site\"'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.titleFormat','\"\"'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.titleTranslationKeyFormat','null'),
('entryTypes.de1bee1c-fb26-4274-8430-e7db93649807.titleTranslationMethod','\"site\"'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.color','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elementCondition','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.autocomplete','false'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.autocorrect','true'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.class','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.dateAdded','\"2024-10-31T17:36:17+00:00\"'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.disabled','false'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.elementCondition','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.id','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.includeInCards','false'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.inputType','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.instructions','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.label','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.max','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.min','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.name','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.orientation','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.placeholder','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.readonly','false'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.requirable','false'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.size','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.step','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.tip','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.title','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.uid','\"538ab32d-4776-43c9-b5b1-307223dbccb3\"'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.userCondition','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.warning','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.0.width','100'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.1.dateAdded','\"2024-10-31T17:37:31+00:00\"'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.1.elementCondition','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.1.fieldUid','\"adc0d524-01bd-4bb3-8f35-ba91943efb90\"'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.1.handle','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.1.includeInCards','false'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.1.instructions','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.1.label','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.1.providesThumbs','false'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.1.required','true'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.1.tip','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.1.uid','\"3ebf00a1-282f-4396-94c8-ee67edeb306d\"'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.1.userCondition','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.1.warning','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.elements.1.width','100'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.name','\"Content\"'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.uid','\"cbd20e82-4895-4185-a26c-d5f8b9d5939a\"'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.fieldLayouts.b2bff3e5-12ee-4726-a791-25ede9062c3b.tabs.0.userCondition','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.handle','\"textonly\"'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.hasTitleField','true'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.icon','\"\"'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.name','\"Text only\"'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.showSlugField','true'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.showStatusField','true'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.slugTranslationKeyFormat','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.slugTranslationMethod','\"site\"'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.titleFormat','\"\"'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.titleTranslationKeyFormat','null'),
('entryTypes.edf4e300-3145-4f61-908d-262ea02dcaa4.titleTranslationMethod','\"site\"'),
('fields.4528f321-cffc-46ae-b89a-8b6956271988.columnSuffix','null'),
('fields.4528f321-cffc-46ae-b89a-8b6956271988.handle','\"textOff\"'),
('fields.4528f321-cffc-46ae-b89a-8b6956271988.instructions','null'),
('fields.4528f321-cffc-46ae-b89a-8b6956271988.name','\"Text OFF\"'),
('fields.4528f321-cffc-46ae-b89a-8b6956271988.searchable','false'),
('fields.4528f321-cffc-46ae-b89a-8b6956271988.settings.byteLimit','null'),
('fields.4528f321-cffc-46ae-b89a-8b6956271988.settings.charLimit','null'),
('fields.4528f321-cffc-46ae-b89a-8b6956271988.settings.code','false'),
('fields.4528f321-cffc-46ae-b89a-8b6956271988.settings.initialRows','4'),
('fields.4528f321-cffc-46ae-b89a-8b6956271988.settings.multiline','false'),
('fields.4528f321-cffc-46ae-b89a-8b6956271988.settings.placeholder','null'),
('fields.4528f321-cffc-46ae-b89a-8b6956271988.settings.uiMode','\"normal\"'),
('fields.4528f321-cffc-46ae-b89a-8b6956271988.translationKeyFormat','null'),
('fields.4528f321-cffc-46ae-b89a-8b6956271988.translationMethod','\"none\"'),
('fields.4528f321-cffc-46ae-b89a-8b6956271988.type','\"craft\\\\fields\\\\PlainText\"'),
('fields.adc0d524-01bd-4bb3-8f35-ba91943efb90.columnSuffix','null'),
('fields.adc0d524-01bd-4bb3-8f35-ba91943efb90.handle','\"textOn\"'),
('fields.adc0d524-01bd-4bb3-8f35-ba91943efb90.instructions','null'),
('fields.adc0d524-01bd-4bb3-8f35-ba91943efb90.name','\"Text ON\"'),
('fields.adc0d524-01bd-4bb3-8f35-ba91943efb90.searchable','false'),
('fields.adc0d524-01bd-4bb3-8f35-ba91943efb90.settings.byteLimit','null'),
('fields.adc0d524-01bd-4bb3-8f35-ba91943efb90.settings.charLimit','null'),
('fields.adc0d524-01bd-4bb3-8f35-ba91943efb90.settings.code','false'),
('fields.adc0d524-01bd-4bb3-8f35-ba91943efb90.settings.initialRows','4'),
('fields.adc0d524-01bd-4bb3-8f35-ba91943efb90.settings.multiline','false'),
('fields.adc0d524-01bd-4bb3-8f35-ba91943efb90.settings.placeholder','null'),
('fields.adc0d524-01bd-4bb3-8f35-ba91943efb90.settings.uiMode','\"normal\"'),
('fields.adc0d524-01bd-4bb3-8f35-ba91943efb90.translationKeyFormat','null'),
('fields.adc0d524-01bd-4bb3-8f35-ba91943efb90.translationMethod','\"none\"'),
('fields.adc0d524-01bd-4bb3-8f35-ba91943efb90.type','\"craft\\\\fields\\\\PlainText\"'),
('fields.da714b55-a04c-4269-85fd-7ab743a0bf2b.columnSuffix','null'),
('fields.da714b55-a04c-4269-85fd-7ab743a0bf2b.handle','\"switch\"'),
('fields.da714b55-a04c-4269-85fd-7ab743a0bf2b.instructions','null'),
('fields.da714b55-a04c-4269-85fd-7ab743a0bf2b.name','\"Switch\"'),
('fields.da714b55-a04c-4269-85fd-7ab743a0bf2b.searchable','false'),
('fields.da714b55-a04c-4269-85fd-7ab743a0bf2b.settings.default','false'),
('fields.da714b55-a04c-4269-85fd-7ab743a0bf2b.settings.offLabel','\"OFF\"'),
('fields.da714b55-a04c-4269-85fd-7ab743a0bf2b.settings.onLabel','\"ON\"'),
('fields.da714b55-a04c-4269-85fd-7ab743a0bf2b.translationKeyFormat','null'),
('fields.da714b55-a04c-4269-85fd-7ab743a0bf2b.translationMethod','\"none\"'),
('fields.da714b55-a04c-4269-85fd-7ab743a0bf2b.type','\"craft\\\\fields\\\\Lightswitch\"'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.columnSuffix','null'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.handle','\"matrix\"'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.instructions','null'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.name','\"Matrix\"'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.searchable','false'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.settings.createButtonLabel','null'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.settings.entryTypes.0','\"edf4e300-3145-4f61-908d-262ea02dcaa4\"'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.settings.entryTypes.1','\"541b2121-af3f-4576-a1a9-bb7a9a50d0b3\"'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.settings.includeTableView','false'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.settings.maxEntries','null'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.settings.minEntries','null'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.settings.pageSize','null'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.settings.propagationKeyFormat','null'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.settings.propagationMethod','\"all\"'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.settings.showCardsInGrid','false'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.settings.viewMode','\"blocks\"'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.translationKeyFormat','null'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.translationMethod','\"site\"'),
('fields.e6df5007-e040-4014-b74c-6addcb50730a.type','\"craft\\\\fields\\\\Matrix\"'),
('meta.__names__.4528f321-cffc-46ae-b89a-8b6956271988','\"Text OFF\"'),
('meta.__names__.4568d78b-06d8-4119-8e75-39932526f3f7','\"Test bug craft\"'),
('meta.__names__.541b2121-af3f-4576-a1a9-bb7a9a50d0b3','\"Condtional\"'),
('meta.__names__.589790d0-ad38-4c42-996e-d0c6dfa8a673','\"Test bug craft\"'),
('meta.__names__.7b15728e-19f1-4195-81f0-5d0656b44c57','\"Page\"'),
('meta.__names__.adc0d524-01bd-4bb3-8f35-ba91943efb90','\"Text ON\"'),
('meta.__names__.da714b55-a04c-4269-85fd-7ab743a0bf2b','\"Switch\"'),
('meta.__names__.de1bee1c-fb26-4274-8430-e7db93649807','\"Default\"'),
('meta.__names__.e6df5007-e040-4014-b74c-6addcb50730a','\"Matrix\"'),
('meta.__names__.edf4e300-3145-4f61-908d-262ea02dcaa4','\"Text only\"'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.defaultPlacement','\"end\"'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.enableVersioning','true'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.entryTypes.0','\"de1bee1c-fb26-4274-8430-e7db93649807\"'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.handle','\"page\"'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.maxAuthors','1'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.name','\"Page\"'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.propagationMethod','\"all\"'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.siteSettings.589790d0-ad38-4c42-996e-d0c6dfa8a673.enabledByDefault','true'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.siteSettings.589790d0-ad38-4c42-996e-d0c6dfa8a673.hasUrls','true'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.siteSettings.589790d0-ad38-4c42-996e-d0c6dfa8a673.template','null'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.siteSettings.589790d0-ad38-4c42-996e-d0c6dfa8a673.uriFormat','\"page/{slug}\"'),
('sections.7b15728e-19f1-4195-81f0-5d0656b44c57.type','\"channel\"'),
('siteGroups.4568d78b-06d8-4119-8e75-39932526f3f7.name','\"Test bug craft\"'),
('sites.589790d0-ad38-4c42-996e-d0c6dfa8a673.baseUrl','\"$PRIMARY_SITE_URL\"'),
('sites.589790d0-ad38-4c42-996e-d0c6dfa8a673.handle','\"default\"'),
('sites.589790d0-ad38-4c42-996e-d0c6dfa8a673.hasUrls','true'),
('sites.589790d0-ad38-4c42-996e-d0c6dfa8a673.language','\"en-US\"'),
('sites.589790d0-ad38-4c42-996e-d0c6dfa8a673.name','\"Test bug craft\"'),
('sites.589790d0-ad38-4c42-996e-d0c6dfa8a673.primary','true'),
('sites.589790d0-ad38-4c42-996e-d0c6dfa8a673.siteGroup','\"4568d78b-06d8-4119-8e75-39932526f3f7\"'),
('sites.589790d0-ad38-4c42-996e-d0c6dfa8a673.sortOrder','1'),
('system.edition','\"solo\"'),
('system.live','true'),
('system.name','\"Test bug craft\"'),
('system.schemaVersion','\"5.3.0.2\"'),
('system.timeZone','\"America/Los_Angeles\"'),
('users.allowPublicRegistration','false'),
('users.defaultGroup','null'),
('users.photoSubpath','null'),
('users.photoVolumeUid','null'),
('users.require2fa','false'),
('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text DEFAULT NULL,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT 0,
  `priority` int(11) unsigned NOT NULL DEFAULT 1024,
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT 0,
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT 0,
  `dateFailed` datetime DEFAULT NULL,
  `error` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vkcpblxnqubpowkckbxpeudwgtxsunltjiai` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_dnnkyebtvtdakzzliwyxwnghvsqztrmaignz` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recoverycodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `recoveryCodes` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sjwdxkwnbznjihwusthruryxejufmpknulnj` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_xvwmqxqdfsxwrlxpohqkqqsljxnihemtrelu` (`sourceId`),
  KEY `idx_xvqwbauozpmliefngpwvvpcyaydpmrhevgtv` (`targetId`),
  KEY `idx_vwpatytreojweqvbuesdlkkcsmxmzaybnsll` (`sourceSiteId`),
  CONSTRAINT `fk_fsrurgdblskbubyybpqvmaevdabdillvbefg` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jmfpwhyxdhmtucejbafyrvbncuzukaoktmma` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_jopovsaqbbozahxhwdsazmxqyfrzzebqpxnk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES
('18dc2f6b','@craft/web/assets/htmx/dist'),
('23923daf','@craft/web/assets/jqueryui/dist'),
('2975adb9','@bower/jquery/dist'),
('3de9eb04','@craft/web/assets/fileupload/dist'),
('4380dcaf','@craft/web/assets/picturefill/dist'),
('46076fc0','@craft/web/assets/authmethodsetup/dist'),
('483861af','@craft/web/assets/xregexp/dist'),
('4a5cb66b','@craft/web/assets/craftsupport/dist'),
('4cf22c13','@craft/web/assets/timepicker/dist'),
('6e342cc2','@craft/web/assets/editsection/dist'),
('6e6cdc9d','@craft/web/assets/vue/dist'),
('71d08fb6','@craft/web/assets/datepickeri18n/dist'),
('75498b2f','@craft/web/assets/feed/dist'),
('7a4c04c6','@craft/web/assets/velocity/dist'),
('7f88d913','@craft/web/assets/jquerytouchevents/dist'),
('7fdb0671','@craft/web/assets/jquerypayment/dist'),
('846a43ef','@craft/web/assets/admintable/dist'),
('95e40010','@craft/web/assets/garnish/dist'),
('a5a77540','@craft/web/assets/matrix/dist'),
('bd563707','@craft/web/assets/fabric/dist'),
('c0aade4','@craft/web/assets/dashboard/dist'),
('cbbf9755','@craft/web/assets/axios/dist'),
('d0cd6a58','@craft/web/assets/conditionbuilder/dist'),
('d34a020c','@craft/web/assets/recententries/dist'),
('e0b3633b','@craft/web/assets/fieldsettings/dist'),
('e6dab60d','@craft/web/assets/iframeresizer/dist'),
('edbbbfba','@craft/web/assets/d3/dist'),
('edf04062','@craft/web/assets/updateswidget/dist'),
('f78e99f3','@craft/web/assets/cp/dist'),
('fbc63bbb','@craft/web/assets/selectize/dist'),
('fcd38199','@craft/web/assets/tailwindreset/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lbdayijhczxixkdqsehgbpebqndilxrgktvl` (`canonicalId`,`num`),
  KEY `fk_wusmshwlyoxxxznewptydkyhhtoawnwiuair` (`creatorId`),
  CONSTRAINT `fk_qxjtprlazmsotkevjfcoystemuvvobrxkmhw` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wusmshwlyoxxxznewptydkyhhtoawnwiuair` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES
(1,2,1,1,''),
(2,7,1,1,''),
(3,12,1,1,NULL),
(4,21,1,1,''),
(5,22,1,1,NULL),
(6,21,1,2,'Applied “Draft 1”'),
(7,27,1,1,NULL),
(8,30,1,1,NULL),
(9,31,1,1,NULL),
(10,21,1,3,'Applied “Draft 1”'),
(11,45,1,1,NULL),
(12,21,1,4,'Applied “Draft 1”'),
(13,49,1,1,NULL),
(14,51,1,1,NULL),
(15,21,1,5,'Applied “Draft 1”'),
(16,56,1,1,NULL),
(17,57,1,1,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_tjbvmclzshzudxblnoprlobchirxgybqbkgh` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES
(1,'email',0,1,' support akufen ca '),
(1,'firstname',0,1,''),
(1,'fullname',0,1,''),
(1,'lastname',0,1,''),
(1,'slug',0,1,''),
(1,'username',0,1,' admin '),
(2,'slug',0,1,' test '),
(2,'title',0,1,' test '),
(3,'slug',0,1,' temp zdxnoegoapgmqkwdknaxvobtzqbymhmnzjbn '),
(3,'title',0,1,''),
(5,'slug',0,1,' test '),
(5,'title',0,1,' test '),
(6,'slug',0,1,' temp fzmbtudtmjkbqufachpqshbevnbgnsumabgn '),
(6,'title',0,1,''),
(7,'slug',0,1,' sdfsdf '),
(7,'title',0,1,' sdfsdf '),
(9,'slug',0,1,' temp bcwpsmyugxpbqnxgzbcajofsrqftgcsatfur '),
(9,'title',0,1,' sdfsd '),
(10,'slug',0,1,' temp axvukrieidfqpfherbkqvptnjmjtvoqqemmm '),
(10,'title',0,1,''),
(11,'slug',0,1,' temp vonfvgtmwztvpdfmlnmgmrzpihdmkuzvicpc '),
(11,'title',0,1,''),
(12,'slug',0,1,' titre '),
(12,'title',0,1,' titre '),
(17,'slug',0,1,' temp iucflxngkmhbuyrjzhnunztvpmmwjjremyom '),
(17,'title',0,1,''),
(19,'slug',0,1,' temp ilbnemxezlecaqyhnzlaxhyjyndgbnfmfecy '),
(19,'title',0,1,''),
(20,'slug',0,1,' temp qsfztirtxgeszcqwqujcjktjfccnekspmwaz '),
(20,'title',0,1,''),
(21,'slug',0,1,' test 2 '),
(21,'title',0,1,' test '),
(22,'slug',0,1,' sdfsdf '),
(22,'title',0,1,' sdfsdf '),
(27,'slug',0,1,' sdfsdf '),
(27,'title',0,1,' sdfsdf '),
(30,'slug',0,1,' 2 '),
(30,'title',0,1,' 2 '),
(31,'slug',0,1,' 1 '),
(31,'title',0,1,' 1 '),
(45,'slug',0,1,' sdfsdf '),
(45,'title',0,1,' sdfsdf '),
(49,'slug',0,1,' sdfsdf '),
(49,'title',0,1,' sdfsdf '),
(51,'slug',0,1,' sdf '),
(51,'title',0,1,' sdf '),
(56,'slug',0,1,' sdfsdf '),
(56,'title',0,1,' sdfsdf '),
(57,'slug',0,1,' sdf '),
(57,'title',0,1,' sdfsdf '),
(61,'slug',0,1,' test 2 '),
(61,'title',0,1,' test '),
(62,'slug',0,1,' sdfsdf '),
(62,'title',0,1,' sdfsdf ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT 0,
  `maxAuthors` smallint(6) unsigned NOT NULL DEFAULT 1,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`previewTargets`)),
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ikfowgojqmchfvhhtszueydhmqcpgihdzmnq` (`handle`),
  KEY `idx_uswrsuxzzhaffjammiwgnwcdgrievxrtoafd` (`name`),
  KEY `idx_vksmafyafcbbocjvfgrpjnpnxggzqxqlwghf` (`structureId`),
  KEY `idx_aftmnjjsqqvjuqttfjqbvbjrrtaeysiacstp` (`dateDeleted`),
  CONSTRAINT `fk_lzztevxjwalubjbcammxvaciwkluwpdnoegm` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES
(1,NULL,'Page','page','channel',1,1,'all','end','[{\"label\":\"Primary entry page\",\"urlFormat\":\"{url}\",\"refresh\":\"1\"}]','2024-10-31 17:33:25','2024-10-31 17:33:25',NULL,'7b15728e-19f1-4195-81f0-5d0656b44c57');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned NOT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_nxpmzhgqelqizywhjqwnelrtpwsuqzavklxa` (`typeId`),
  CONSTRAINT `fk_ekebhwmkaakfvnuunbbixkfwtybubcypkigo` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nxpmzhgqelqizywhjqwnelrtpwsuqzavklxa` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
INSERT INTO `sections_entrytypes` VALUES
(1,1,1);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vlluvtjoxbyytcfnpznliqnmcfcrfhfkqagd` (`sectionId`,`siteId`),
  KEY `idx_erucazunzktjwmsmijhzjgelkrwrpojwvkfq` (`siteId`),
  CONSTRAINT `fk_lumcgtinmumaynxpmunxrixbqfhymejvefkm` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_paunpfxkeddkmvlthsmjqrftfjnybjvholkq` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES
(1,1,1,1,'page/{slug}',NULL,1,'2024-10-31 17:33:25','2024-10-31 17:33:25','f11bbba4-9fa3-4f02-946b-b6f4e1698061');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jtjiifspzxsoanacfjmzyjutudjykdeetmck` (`uid`),
  KEY `idx_mdmmtpfweleaoommcrbfkvsggjawyjkpjpnx` (`token`),
  KEY `idx_rxlnncnpkopyvumppamztwnciacyyihprabv` (`dateUpdated`),
  KEY `idx_cpuiybgjiqahvwhafsyxhwcvclqkwoaazgze` (`userId`),
  CONSTRAINT `fk_kubwqnisdhyrlrxhwvkafgdjzmwlepfbfara` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
(2,1,'AhfDtal7oX9A_krB74n2TC6qLKgJs-va4ClYvRLpQd4bIvJ3e3yrrve7ivwkhFFVlOjXNabejgqwZdYEpvRkuvPWR5-U3QpFoor2','2024-10-31 17:51:41','2024-10-31 17:51:41','93f452b6-9bfe-4824-8f92-45d985add23c');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_saozvlgwvpgyzhhlsvwhaaqbrlrzsmanpakn` (`userId`,`message`),
  CONSTRAINT `fk_uqiaiiutwtubwwjfmepkmlgkbjthfxctirec` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pslldsjfoddgadgacdklmkrwtshqsnkogavt` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES
(1,'Test bug craft','2024-10-31 17:29:17','2024-10-31 17:29:17',NULL,'4568d78b-06d8-4119-8e75-39932526f3f7');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 0,
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lgmvkroudhzlwekgzfezpjrdrhoznyrbulrd` (`dateDeleted`),
  KEY `idx_jhqvwtfrnikgxcelwgpppeapzkkkhubyqahg` (`handle`),
  KEY `idx_celrkzkptnrrfgwhnkibnaaezpvwsodgzzoi` (`sortOrder`),
  KEY `fk_bppbrtkqhbykjxbneogisdaobqfvdterrbat` (`groupId`),
  CONSTRAINT `fk_bppbrtkqhbykjxbneogisdaobqfvdterrbat` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES
(1,1,1,'true','Test bug craft','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-10-31 17:29:17','2024-10-31 17:29:17',NULL,'589790d0-ad38-4c42-996e-d0c6dfa8a673');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_identities`
--

DROP TABLE IF EXISTS `sso_identities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sso_identities` (
  `provider` varchar(255) NOT NULL,
  `identityId` varchar(255) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`provider`,`identityId`,`userId`),
  KEY `fk_lihfwihvxjutzybhfllioeolbymodvbqcjqp` (`userId`),
  CONSTRAINT `fk_lihfwihvxjutzybhfllioeolbymodvbqcjqp` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_identities`
--

LOCK TABLES `sso_identities` WRITE;
/*!40000 ALTER TABLE `sso_identities` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_identities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qrjgrhxywkcxttlzykifuzrqxurmmrljgyod` (`structureId`,`elementId`),
  KEY `idx_krcwdkqtediagjspngwfjihzqmhnqmzhynwe` (`root`),
  KEY `idx_aktbwrqnnkjkpfolrosudlenspqenbkylhqf` (`lft`),
  KEY `idx_dryhxrhvjytzwltamzemleaypigpphqdvqjk` (`rgt`),
  KEY `idx_jwdcuvuztqgankdmuqlrefsrocslrpqqdida` (`level`),
  KEY `idx_ixlazwwgevwisrqdszzjeowvgcsrsgenjweg` (`elementId`),
  CONSTRAINT `fk_sibepltbayqjvdedsmziqsofumpdooziahum` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ymdxcwlnpfhbvcuowbwyppyinajlsmcrxspi` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bqjfdneztbfalktmtihjxyiliatufvudkkkl` (`key`,`language`),
  KEY `idx_zsqyfkbqsofcsmvjugnedjvunovibwvcufol` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xmwduamfklssojpomptyfrtftbikprlpdejb` (`name`),
  KEY `idx_czeiukbeqhomfntxqfbztcewqxzjnwntuntn` (`handle`),
  KEY `idx_vhmfsqeaqzjgpjralvquimnzlsyjyldzfhda` (`dateDeleted`),
  KEY `fk_fjiqfrngnroxuezjnzucpvnpdvusmtjybwyb` (`fieldLayoutId`),
  CONSTRAINT `fk_fjiqfrngnroxuezjnzucpvnpdvusmtjybwyb` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aruetkiublkhzfyqdupjcsxfwsuajlulligi` (`groupId`),
  CONSTRAINT `fk_cgajlmevckfxqsbieeycgczrqwawbcpihogw` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_idbipwztafpbinpwchegusmibankfvhpsgyj` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text DEFAULT NULL,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rouhezoixhlgstdnjdoiuhhvhbucreuvmtyq` (`token`),
  KEY `idx_lalivfzmulxqfmslfwdkfhdswrlchpsbzoza` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xtckpfkcocsxtpyeweaurvjnluhhsmtfxica` (`handle`),
  KEY `idx_mpbjauotopuzsvscxwcacdxecfytjibfjrwx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hojptaedsaoivzkrdkpocjstcyziyfndgawa` (`groupId`,`userId`),
  KEY `idx_cmygoltqrkiudpzibtfkcuzqgkienxounhiu` (`userId`),
  CONSTRAINT `fk_bxgziwpvmcpralfbcrfzisdsfcwdhhbbwdbg` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hdhyujrgtsordslfwhoehupdxoujvluwarnn` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ounpuyzisgaqzsjolfdeftmljpbwybvrgbcy` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gwperpazvwzkuhesbcwmlopbxgmabwguvfbu` (`permissionId`,`groupId`),
  KEY `idx_djlyqstvurtotonauhbexisrllhshrfpfmfj` (`groupId`),
  CONSTRAINT `fk_glfrgcruxmnhymcvdvevcsfhjmwbwdkaviqs` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ntblxyvrkybqqzqaljfmddqksmyjdevroiek` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_esbykqnineeioencbvkdiuwlhgbiywldxfap` (`permissionId`,`userId`),
  KEY `idx_vzknfqlqyltjedrcnhobwfzqlkhxaszihcic` (`userId`),
  CONSTRAINT `fk_ekyclofewxyqruuuiootlswnsusdpkrmbiww` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_esdktyibyhqtekhwowuxrwglutgstsrfprnk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`preferences`)),
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_fkmkxgvixnwtclvaibhqgyvogihoigiephlk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES
(1,'{\"language\":\"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `pending` tinyint(1) NOT NULL DEFAULT 0,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `suspended` tinyint(1) NOT NULL DEFAULT 0,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT 0,
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT 0,
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_huklbucfgvypuisbzglquzujocgbxmmtsahv` (`active`),
  KEY `idx_ezvcspnyogfkhagimwhlbvqnfskllpcdnyvj` (`locked`),
  KEY `idx_thjcdypafnojsmloclgomjbrlyvkdfkbvhij` (`pending`),
  KEY `idx_qlnauvvnmbeakhmlsjlhhfwhgwpeocgouybt` (`suspended`),
  KEY `idx_nwgpujnsaqkumzeiucbzcbvrhbsefewgktpq` (`verificationCode`),
  KEY `idx_gkcjkmgpgjntiokkgaazryeqihglnqkhgxtz` (`email`),
  KEY `idx_ovegcjoznebtfenrpzajvzsvogbtldhuxhqu` (`username`),
  KEY `fk_wvyhhcsaqhjtpfhaembsbpsdrxtvwicnkqox` (`photoId`),
  CONSTRAINT `fk_hewrbzafngwmdqnrpjbtbrtucjssjzgeeltn` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wvyhhcsaqhjtpfhaembsbpsdrxtvwicnkqox` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'support@akufen.ca','$2y$13$VyWUZrKjrSSfMOV5a4lLDulVX7JQSmc5Ss8taEqihVRxH5wKnmU.y','2024-10-31 17:51:41',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-10-31 17:51:41','2024-10-31 17:29:17','2024-10-31 17:51:41');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mizfctihtguwjmjtzsqubrndudriqhhrvris` (`name`,`parentId`,`volumeId`),
  KEY `idx_ditqjkuhmckemzvsjqndthdtgbshgcogbpmc` (`parentId`),
  KEY `idx_tlhamztuywixstwgmmityzfetxpcfmwvhpyh` (`volumeId`),
  CONSTRAINT `fk_bnsqvjheulggunyewtfuexurxuerbuzvxuuw` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_njdumcwgqwfkwmklfsjooaniiqwlluqgngxt` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gdfvtvlvvojbpcyxdwahcolnxgbrtuaoprwa` (`name`),
  KEY `idx_uwpespxacrmiqpwuqyctteqvrvhyifaksubv` (`handle`),
  KEY `idx_nxztyywdkcxkjvlrpbflriyucpzrxaelidme` (`fieldLayoutId`),
  KEY `idx_jgyyxjesjxowujxjullmylnbtvqifbnxtdsw` (`dateDeleted`),
  CONSTRAINT `fk_gpkyrjyhffocvcyqluuxanjsdzgfmegiofrm` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webauthn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text DEFAULT NULL,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_vnmvohdzfjjkuxbsvqbesygtmefzdobstvjk` (`userId`),
  CONSTRAINT `fk_vnmvohdzfjjkuxbsvqbesygtmefzdobstvjk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rfixjlcnfkqctiphpnkgkippeljgyzxfcyag` (`userId`),
  CONSTRAINT `fk_wgwlvzafjazfwzzazheloiznkimtyxdewuwr` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES
(1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2024-10-31 17:30:24','2024-10-31 17:30:24','f9f31ea0-c2f6-4814-8b49-4c327a6b0997'),
(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-10-31 17:30:24','2024-10-31 17:30:24','f2548e1b-dab0-487d-86bf-6b485fd30bcb'),
(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-10-31 17:30:24','2024-10-31 17:30:24','091d3316-982a-4f09-a732-815fd41e3d50'),
(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2024-10-31 17:30:24','2024-10-31 17:30:24','224ae016-ee29-4e4f-895f-20e9bb103d73');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-31 13:51:46
